#ifndef __al_included_allegro5_aintern_x_h
#define __al_included_allegro5_aintern_x_h

#include <X11/Xlib.h>

typedef struct ALLEGRO_SYSTEM_XGLX ALLEGRO_SYSTEM_XGLX;
typedef struct ALLEGRO_DISPLAY_XGLX ALLEGRO_DISPLAY_XGLX;

#endif
